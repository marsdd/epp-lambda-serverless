-- Insert ID into pathway.training for NA training row
INSERT INTO epp.pathway.training (id, training_provider_name, training_provider_address, url, training_name, duration_cat_id, duration_cat_name, online) VALUES (999, 'NA', 'NA', 'NA', 'NA', NULL, 'NA', NULL)
;

-- Update pathway.training_occ so that 432 occupations are associated with the NA training row
UPDATE epp.pathway.training_occ SET training_id = 999 WHERE training_id = 290 AND soc_code NOT LIKE '%15-1199.01%' -- this is the one correct instance of training ID 290
;
