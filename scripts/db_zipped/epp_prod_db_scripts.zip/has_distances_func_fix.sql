drop function if exists epp.pathway.update_socs_has_distances();

create function epp.pathway.update_socs_has_distances() returns void
language plpgsql
as
$$
DECLARE
sql VARCHAR;

BEGIN
sql = ' UPDATE epp.pathway.occupation ' ||
' SET has_distances = TRUE ' ||
' WHERE soc_code IN ( ' ||
'  SELECT DISTINCT T.soc_start ' ||
'  FROM epp.pathway.overlap T ' ||
'  WHERE T.dist_all_alt IS NOT NULL ' ||
'  ) ';
EXECUTE sql;

END;
$$;