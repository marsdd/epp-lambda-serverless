create database epp;
--DO
--$do$
--BEGIN
--   IF EXISTS (SELECT 1 FROM pg_database WHERE datname = 'epp') THEN
--      RAISE NOTICE 'Database already exists';
--   ELSE
--      PERFORM dblink_exec('dbname=' || current_database()  -- current db
--                        , 'CREATE DATABASE epp');
--   END IF;
--END
--$do$;

\connect epp;
create schema if not exists pathway;

alter table pathway.training_occ drop constraint if exists training_occ_training_id_fk;

TRUNCATE
pathway.job_zones,
pathway.occ_ability,
pathway.occ_education_canada,
pathway.occ_skill,
pathway.occupation,
pathway.overlap,
pathway.training,
pathway.training_occ,
pathway.alternate_titles
;

DROP TABLE IF EXISTS
pathway.job_zones,
pathway.occ_ability,
pathway.occ_education_canada,
pathway.occ_skill,
pathway.occupation,
pathway.overlap,
pathway.training,
pathway.training_occ,
pathway.alternate_titles
;

DROP FUNCTION IF EXISTS
pathway.get_abilities,
pathway.get_details,
pathway.get_education,
pathway.get_overlap_2,
pathway.get_skills,
pathway.get_socs,
pathway.get_training,
pathway.get_alt_titles,
pathway.update_socs_has_distances
;

create table if not exists pathway.alternate_titles
(
	id serial
		constraint alternate_titles_pk
			primary key,
	onetsoc_code text,
	alternate_title text,
	short_title text,
	sources text
);

create table if not exists pathway.job_zones
(
	id serial not null
		constraint job_zones_pk
			primary key,
	onetsoc_code text,
	job_zone integer,
	date_updated text,
	domain_source text
);

create table if not exists pathway.occ_skill
(
  id              serial not null
    constraint occ_skill_pkey
      primary key,
  soc_code        varchar(100),
  attr_id         varchar(50),
  attr_name       varchar(255),
  attr_level      real,
  attr_importance real
);


create unique index occ_skill_id_uindex
  on pathway.occ_skill (id);

create table if not exists pathway.occ_ability
(
  id              serial not null
    constraint occ_ability_pkey
      primary key,
  soc_code        varchar(100),
  attr_id         varchar(50),
  attr_name       varchar(255),
  attr_level      real,
  attr_importance real
);


create unique index occ_ability_id_uindex
  on pathway.occ_ability (id);


create table if not exists pathway.occ_education_canada
(
  id              serial not null
    constraint occ_education_canada_pkey
      primary key,
  soc_code        text,
  cat             integer,
  cat_description text,
  percentage      numeric
);


create unique index occ_education_canada_id_uindex
  on pathway.occ_education_canada (id);

create table if not exists pathway.occupation
(
  id            serial not null
    constraint occupation_1_pkey
      primary key,
  soc_code      varchar(100),
  title         varchar(500),
  auto_risk     real,
  salary_min    integer,
  salary_max    integer,
  description   text,
  has_distances boolean default false
);


create unique index occupation_1_id_uindex
  on pathway.occupation (id);

create unique index occupation_title_uindex
  on pathway.occupation (title);

create unique index occupation_soc_code_uindex
  on pathway.occupation (soc_code);

create table if not exists pathway.overlap
(
  id                  serial not null
    constraint overlap_1_pkey
      primary key,
  soc_start           varchar(255),
  soc_end             varchar(255),
  risk_start          numeric,
  risk_end            numeric,
  salarymax_start     integer,
  salarymax_end       integer,
  dist_all            numeric,
  dist_skills         numeric,
  dist_abilities      numeric,
  dist_knowledge      numeric,
  dist_interests      numeric,
  dist_workstyles     numeric,
  dist_workvalues     numeric,
  dist_workactivities numeric,
  dist_workcontext    numeric,
  dist_all_alt        numeric
);


create unique index overlap_1_id_uindex
  on pathway.overlap (id);


create table if not exists pathway.training
(
  id                        integer not null
    constraint training_pk
      primary key,
  training_provider_name    text,
  training_provider_address text,
  url                       text,
  training_name             text,
  duration_cat_id           integer,
  duration_cat_name         text,
  online                    bit
);


create unique index "training_id_uindex"
  on pathway.training (id);

create table if not exists pathway.training_occ
(
  id          serial not null
    constraint training_occ_pk
      primary key,
  training_id integer
    constraint training_occ_training_id_fk
      references pathway.training,
  soc_code    text
);


create unique index training_occ_id_uindex
  on pathway.training_occ (id);

create index training_occ_soc_code_index
  on pathway.training_occ (soc_code);


create function pathway.get_details(soc character varying) returns TABLE
                                                           (
                                                             soc_code    character varying,
                                                             title       character varying,
                                                             auto_risk   real,
                                                             salary_min  integer,
                                                             salary_max  integer,
                                                             description text
                                                           )
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT A.soc_code,
           A.title,
           A.auto_risk,
           A.salary_min,
           A.salary_max,
           A.description
    FROM epp.pathway.occupation A
    WHERE A.soc_code = soc;
END;
$$;


create function pathway.get_abilities(soc character varying) returns TABLE
                                                             (
                                                               soc_code        character varying,
                                                               attr_id         character varying,
                                                               attr_name       character varying,
                                                               attr_level      real,
                                                               attr_importance real
                                                             )
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT a.soc_code,
           a.attr_id,
           a.attr_name,
           a.attr_level,
           a.attr_importance
    FROM epp.pathway.occ_ability a
    WHERE a.soc_code = soc;
END;
$$;


create function pathway.get_education(soc character varying) returns TABLE
                                                             (
                                                               soc_code        text,
                                                               cat             integer,
                                                               cat_description text,
                                                               percentage      numeric
                                                             )
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT a.soc_code,
           a.cat,
           a.cat_description,
           a.percentage
    FROM epp.pathway.occ_education_canada a
    WHERE a.soc_code = soc;
END;
$$;


create function pathway.get_skills(soc character varying) returns TABLE
                                                          (
                                                            soc_code        character varying,
                                                            attr_id         character varying,
                                                            attr_name       character varying,
                                                            attr_level      real,
                                                            attr_importance real
                                                          )
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT a.soc_code,
           a.attr_id,
           a.attr_name,
           a.attr_level,
           a.attr_importance
    FROM epp.pathway.occ_skill a
    WHERE a.soc_code = soc;
END;
$$;


create function pathway.get_overlap_2(soc character varying, num integer DEFAULT 10, soc_exclude character varying[] DEFAULT '{}'::character varying[]) returns TABLE(soc_code character varying, title character varying, description text, risk_start numeric, risk_end numeric, salarymax_start integer, salarymax_end integer, dist_all numeric)
  language plpgsql
as
$$
BEGIN
RETURN QUERY
SELECT
  A.soc_end AS soc_code,
  B.title,
  B.description,
  A.risk_start,
  A.risk_end,
  A.salarymax_start,
  A.salarymax_end,
  A.dist_all_alt dist_all
FROM epp.pathway.overlap A
  LEFT JOIN epp.pathway.occupation B
    ON A.soc_end = B.soc_code
  LEFT JOIN epp.pathway.job_zones Z1
    ON A.soc_start = Z1.onetsoc_code
  LEFT JOIN epp.pathway.job_zones Z2
    ON A.soc_end = Z2.onetsoc_code
WHERE
  A.dist_all_alt IS NOT NULL
  AND A.soc_start = ltrim(rtrim(soc))
  AND A.soc_end <> ALL (soc_exclude) -- exclude passed in onetsoc codes
AND ((A.salarymax_end >= (A.salarymax_start * 0.8)) OR (A.salarymax_end IS NULL OR A.salarymax_start IS NULL)) -- no results with more than a 20% decrease in salary
AND ((Z2.job_zone >= Z1.job_zone)OR (Z1.job_zone IS NULL OR Z2.job_zone IS NULL)) -- no results that are a step down in ONET job zones (level of preparation required for job)
ORDER BY
  A.dist_all_alt ASC
--   ,A.risk_end ASC
LIMIT num;
END;
$$;


create function pathway.update_socs_has_distances() returns void
  language plpgsql
as
$$
DECLARE
  sql VARCHAR;

BEGIN
  sql = ' UPDATE epp.pathway.occupation ' ||
        ' SET has_distances = TRUE ' ||
        ' WHERE soc_code IN ( ' ||
        '  SELECT DISTINCT T.soc_start ' ||
        '  FROM epp.pathway.overlap T ' ||
        '  WHERE T.dist_all IS NOT NULL ' ||
        '  ) ';
  EXECUTE sql;

END;
$$;


create function pathway.get_socs(limitperpage integer DEFAULT NULL::integer, pageoffset integer DEFAULT NULL::integer,
                         active boolean DEFAULT true) returns TABLE
                                                              (
                                                                soc_code character varying,
                                                                title    character varying
                                                              )
  language plpgsql
as
$$
DECLARE
  sql VARCHAR;

BEGIN
  sql = 'SELECT DISTINCT ' ||
        'a.soc_code, ' ||
        'a.title ' ||
        'FROM ' ||
        'epp.pathway.occupation a ';

  IF active THEN
    sql = sql || ' WHERE a.has_distances = TRUE ';
  END IF;

  sql = sql || ' ORDER BY a.soc_code ';

  IF limitPerPage IS NOT NULL AND limitPerPage > 0 THEN
    sql = sql || ' LIMIT ' || limitPerPage;
  END IF;

  IF pageOffset IS NOT NULL AND pageOffset > 0 THEN
    sql = sql || ' OFFSET ' || (pageOffset - 1) * limitPerPage;
  END IF;

  RETURN QUERY EXECUTE sql;
END;
$$;


create function pathway.get_training(soc text) returns TABLE
                                               (
                                                 soc_code                  text,
                                                 training_name             text,
                                                 url                       text,
                                                 training_provider_name    text,
                                                 training_provider_address text,
                                                 duration_cat_name         text,
                                                 online                    bit
                                               )
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT b.soc_code,
           a.training_name,
           a.url,
           a.training_provider_name,
           a.training_provider_address,
           a.duration_cat_name,
           a.online
    FROM epp.pathway.training a
           INNER JOIN epp.pathway.training_occ b
                      ON a.id = b.training_id
    WHERE b.soc_code = soc;
END;
$$;


create function pathway.get_alt_titles(soc text, limitrows integer DEFAULT NULL::integer) returns TABLE(alternate_titles text)
	language plpgsql
as $$
DECLARE
  sql VARCHAR;

BEGIN
  sql= 'SELECT ' ||
       'a.alternate_title as alternate_titles ' ||
       'FROM ' ||
       'epp.pathway.alternate_titles a ' ||
       'WHERE a.onetsoc_code = ''' || soc || '''';

 IF limitrows IS NOT NULL THEN
    sql = sql || ' LIMIT ' || limitrows;
  END IF;
RETURN QUERY EXECUTE sql;
END;
$$;
